$(document).ready(function() {
    "use strict";
    $(".timepicker").timepicker();
});